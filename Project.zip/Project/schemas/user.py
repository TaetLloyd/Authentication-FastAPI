from fastapi import FastAPI, Query
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import List, Optional

#Pydantic
class Login(BaseModel):
    username: str
    role: int
    password: str

class SearchUser(BaseModel):
    username:str

class UserCreate(BaseModel):
    username: str
    role_id: int
    password: str

class UserInDB(BaseModel):
    id: int
    hashed_password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: str = None

class TodoBase(BaseModel):
    title: str
    description: str
    
class TodoUpdate(TodoBase):
    completed: bool

class TodoInDB(TodoBase):
    id: int
    completed: bool
    created_at: datetime
    user_id: int

class User(BaseModel):
    username: str
    password: str
    role: int

class Todo(BaseModel):
    id: int
    title: str
    description: str
    status: str
    due_date: str
    category_id: Optional[int] = None
    assigned_to: Optional[int] = None

class Category(BaseModel):
    id: int
    name: str
    todos: List[int] = []

class TodoCreate(BaseModel):
    title: str
    description: str
    done: bool
    owner_id: int
    

class PaginateParams(BaseModel):
    size: int =Query(default=10, description="Number of items per page")
    page: int =Query(default=1, description="Page number")
    items: int =Query(default=0, description="Total number of items")
