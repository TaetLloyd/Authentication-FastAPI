import asyncio
from fastapi import FastAPI, HTTPException, Depends, status, Query
from fastapi_pagination import Page
from fastapi_pagination.paginator import paginate
from fastapi.security import HTTPAuthorizationCredentials, OAuth2PasswordBearer, OAuth2PasswordRequestForm
from tokenize import Token
from typing import List
from models.user import Base, create_user, Role, Category, todo_categories,Todos
from fastapi import APIRouter
from config.db import conn,SessionLocal
from schemas.user import TodoCreate, Todo, TodoUpdate, UserCreate, User, TodoBase, SearchUser, Login
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from fastapi import BackgroundTasks
import uvicorn


SECRET_KEY = "secret"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Password hashing
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

# OAuth2 password bearer
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# FastAPI app
app = FastAPI()
router=APIRouter()

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Authorization function
def get_current_user(token: str = Depends(oauth2_scheme)):
    # Authentication
    if token != "validtoken":
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return User


# Routes for managing user roles and permissions (admin only)
@app.post("/users/{user_id}/assign-role", tags=["Admin Use"])
def assign_role(username: str, role: str, password=str, db:Session = Depends(get_db)):
    user=db.query(create_user).filter(username == username, role==role, password==password).first()
    if role != "1":
        raise HTTPException(status_code=403, detail="Permission denied")
    if not user or not pwd_context.verify(password, user.password):
        raise HTTPException(status_code=404, detail="User not found or wrong password")
    return {"message": f"Role assigned to user {username}"}

# Routes for managing todos (authorization required)
@app.get("/todos/", tags=["Admin Use"] )
def get_todos(username: str,role: int, password: str, db: Session = Depends(get_db)):
    user=db.query(create_user).filter(username == username, role==role, password==password).first()
    if not user or not pwd_context.verify(password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",)
    # if role != "1":
        # return {"message": "User can not access users"}
    
    todos=db.query(Todos).all()
    return todos

@app.get("/user/", tags=["Admin Use"])
def get_user(username: str,role: int, password: str, db: Session = Depends(get_db)):
    user=db.query(create_user).filter(username == username, role==role, password==password).first()
    if not user or pwd_context.verify(password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid password",)
    if role >= 2:
        return {"message": "User can not access users"}
    
    users=db.query(create_user).all()
    return users
  
    
# Pagination and filtering example
@app.get("/todos/paginated/",response_model=List[Todo], tags=["Admin Use"])
def get_paginated_todos(username: str,role: int, password: str,skip: int = 0, limit: int = 10,db: Session = Depends(get_db)):
    user=db.query(create_user).filter(username == username, role==role, password==password).first()
    if role != "1":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
              detail="Permission denied")
    if not user or not pwd_context.verify(password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",)
    return list(Todo.values())[skip : skip + limit]

# AsyncIO
def process_todo(todo_id: int):
    #asyncIO function
    todo = Todo.get(todo_id)
    if todo:
        todo.status = "completed"

@app.post("/todos/{todo_id}/complete",response_model=UserCreate, tags=["Admin Use"])
async def complete_todo(todo_id: int, background_tasks: BackgroundTasks, current_user: User = Depends(get_db)):
    if current_user.role != "1":
        raise HTTPException(status_code=403, detail="Permission denied")
    background_tasks.add_task(process_todo, todo_id)
    return {"message": "Todo completion scheduled"}


# Endpoint for user registration
@app.post("/register/Role 1: admin, Role 2 regular ",response_model=UserCreate, tags=["Authentication"])
def register_user(username: str,role: int, password: str, db: Session = Depends(get_db)):
    hashed_password = pwd_context.hash(password)
    user = create_user(username=username,role_id=role, password=hashed_password)
    
    if role > 2:
        raise HTTPException(
            status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
            detail="Invalid role id"
        )
    
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


# Endpoint for creating a new todo
@app.post("/todos/", response_model=TodoCreate,tags=["Todoes"])
def create_todo(todo_data: TodoCreate, db: Session = Depends(get_db)):
    todo_dict=todo_data.dict()
    todo = Todos(**todo_dict)
    db.add(todo)
    db.commit()
    db.refresh(todo)
    return {"messege":"Todo created successfully","todo":todo}

# Endpoint for updating a todo
@app.put("/todos/{todo_id}", response_model=TodoUpdate,tags=["Todoes"])
def update_todo(todo_id: int, todo_data: dict, db: Session = Depends(get_db)):
    todo = db.query(Todos).filter(Todos.id == todo_id).first()
    if not todo:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Todo not found")
    for key, value in todo_data.items():
        setattr(todo, key, value)
    db.commit()
    db.refresh(todo)
    return {"messege":"Todo updated successfully","todo":todo}
 

# Endpoint for deleting a todo
@app.delete("/todos/{todo_id}",tags=["Todoes"])
def delete_todo(todo_id: int, db: Session = Depends(get_db)):
    todo = db.query(Todo).filter(Todo.id == todo_id).first()
    if not todo:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Todo not found")
    db.delete(todo)
    db.commit()
    return {"message": "Todo deleted successfully"}


# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
