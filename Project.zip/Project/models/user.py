from sqlalchemy import Boolean, Column, DateTime, Integer, String, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from typing import Optional
from datetime import datetime, timedelta
from config.db import Base


# User Model
class create_user(Base):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    password = Column(String(100))
    role_id = Column(Integer)

    role = relationship("Role", back_populates="users")
    todos = relationship("Todos", back_populates="owner")


# Role Model
class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer,ForeignKey("user.role_id"), primary_key=True, index=True)
    name = Column(String(50), unique=True, index=True), ForeignKey("user.role_id")

    users = relationship("create_user", back_populates="role")

# Todo Model
class Todos(Base):
    __tablename__ = "todos"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100))
    description = Column(String(255))
    done = Column(Boolean, default=False)
    owner_id = Column(Integer, ForeignKey("user.id"))

    owner = relationship("create_user", back_populates="todos")
    categories = relationship("Category", secondary="todo_categories", back_populates="todos")


# Category Model
class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True)

    todos = relationship("Todos", secondary="todo_categories", back_populates="categories")


# Association Table for Todo and Category Many-to-Many Relationship
todo_categories = Table(
    "todo_categories",
    Base.metadata,
    Column("todo_id", Integer, ForeignKey("todos.id")),
    Column("category_id", Integer, ForeignKey("categories.id")),
)


